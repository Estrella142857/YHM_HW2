package com.example.chapter2.recycler;

import java.util.ArrayList;
import java.util.List;

public class TestData {

    int img;
    String title;
    String time;

    public TestData(int img, String title, String time) {
        this.img = img;
        this.title = title;
        this.time = time;
    }
}
