package com.example.chapter2.recycler;

import com.example.chapter2.R;

import java.util.ArrayList;
import java.util.List;

public class TestDataSet {
    public static List<TestData> getData() {
        List<TestData> result = new ArrayList();
        result.add(new TestData(R.drawable.ic_launcher_background, "抖音小助手","刚刚"));
        result.add(new TestData(R.drawable.ic_launcher_background, "游戏小助手","22:59"));
        result.add(new TestData(R.drawable.ic_launcher_background, "系统消息","22:50"));
        result.add(new TestData(R.drawable.ic_launcher_background, "赵一","20:08"));
        result.add(new TestData(R.drawable.ic_launcher_background, "钱二","17:37"));
        result.add(new TestData(R.drawable.ic_launcher_background, "孙三","15:24"));
        result.add(new TestData(R.drawable.ic_launcher_background, "李四","14:00"));
        result.add(new TestData(R.drawable.ic_launcher_background, "周五","13.56"));
        result.add(new TestData(R.drawable.ic_launcher_background, "吴六","13:25"));
        result.add(new TestData(R.drawable.ic_launcher_background, "郑七","13:09"));
        result.add(new TestData(R.drawable.ic_launcher_background, "王八","12.22"));
        return result;
    }
}
